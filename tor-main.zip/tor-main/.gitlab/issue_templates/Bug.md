### Summary



### Steps to reproduce:

1. Step 1
2. ...

### What is the current bug behavior?



### What is the expected behavior?



### Environment

- Which version of Tor are you using? Run `tor --version` to get the version if you are unsure.
- Which operating system are you using? For example: Debian GNU/Linux 10.1, Windows 10, Ubuntu Xenial, FreeBSD 12.2, etc.
- Which installation method did you use? Distribution package (apt, pkg, homebrew), from source tarball, from Git, etc.

### Relevant logs and/or screenshots



### Possible fixes



/label ~Bug
